import pandas as pd
import mysql.connector
import os
import re
import time
import threading

# Thông tin thư mục và database
folders = {
    "In_E01": r"D:\Intern\Linked_Folder\In_E01",  # Thư mục cho traffic in
    "Out_E00": r"D:\Intern\Linked_Folder\Out_E00"  # Thư mục cho traffic out
}
db_config = {
    "user": "root",
    "password": "Lehoaiphong123",
    "host": "localhost",  # Địa chỉ MySQL trên PC thật
    "database": "network_monitoring"
}

# Kết nối đến MySQL
def connect_to_db():
    return mysql.connector.connect(**db_config)

# Hàm đọc file CSV cũ nhất từ thư mục
def read_oldest_csv(folder_path):
    csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
    if not csv_files:
        print(f"No CSV files found in {folder_path}.")
        return None
    oldest_file = min(csv_files, key=lambda x: os.path.getctime(os.path.join(folder_path, x)))
    file_path = os.path.join(folder_path, oldest_file)
    return file_path

# Hàm xử lý và lưu từng dòng dữ liệu vào MySQL
def process_and_save_data(folder_name):
    while True:
        folder_path = folders[folder_name]
        csv_file_path = read_oldest_csv(folder_path)
        if csv_file_path:
            df = pd.read_csv(csv_file_path)
            df = df[['Date Time', 'Traffic In (Speed)', 'Traffic Out (Speed)']].iloc[:4]

            df['Traffic In (Speed)'] = df['Traffic In (Speed)'].apply(lambda x: float(re.search(r"[\d.]+", str(x)).group()) if pd.notna(x) else None)
            df['Traffic Out (Speed)'] = df['Traffic Out (Speed)'].apply(lambda x: float(re.search(r"[\d.]+", str(x)).group()) if pd.notna(x) else None)

            df.dropna(subset=['Traffic In (Speed)', 'Traffic Out (Speed)'], inplace=True)
            df['Date Time'] = pd.to_datetime(df['Date Time'], format='%m/%d/%Y %I:%M:%S %p')
            df['Date Time'] = df['Date Time'].dt.tz_localize('Asia/Ho_Chi_Minh').dt.tz_convert('UTC').dt.strftime('%Y-%m-%d %H:%M:%S')

            table_name = 'network_traffic_in_e01' if folder_name == 'In_E01' else 'network_traffic_out_e00'

            for _, row in df.iterrows():
                data_to_insert = [(row['Date Time'], row['Traffic In (Speed)'], row['Traffic Out (Speed)'])]
                save_data_to_mysql(data_to_insert, table_name)
                print(f"Row saved to MySQL in {table_name}.")
                time.sleep(30)  # Chờ 30 giây trước khi lưu dòng tiếp theo

            os.remove(csv_file_path)
            print(f"File {csv_file_path} deleted after processing.")

        else:
            print(f"No file found to process in {folder_name}.")


# Hàm lưu dữ liệu vào MySQL
def save_data_to_mysql(data, table_name):
    conn = connect_to_db()
    cursor = conn.cursor()
    insert_query = f"""
        INSERT INTO {table_name} (datetime, traffic_in, traffic_out)
        VALUES (%s, %s, %s)
    """
    cursor.executemany(insert_query, data)
    conn.commit()
    cursor.close()
    conn.close()

if __name__ == "__main__":
    thread_in_e01 = threading.Thread(target=process_and_save_data, args=("In_E01",))
    thread_out_e00 = threading.Thread(target=process_and_save_data, args=("Out_E00",))

    thread_in_e01.start()
    thread_out_e00.start()

    thread_in_e01.join()
    thread_out_e00.join()
